"""Loss functions."""
